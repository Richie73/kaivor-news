
"""
Kaivor Release Tools
"""

import subprocess

from modules.developer.ui import (
    title,
    start_timer,
    end_timer,
    success,
    error,
)


def build_release():

    start_timer()

    title("BUILD RELEASE")

    try:

        result = subprocess.run(
            ["python", "scripts/release.py"],
            capture_output=True,
            text=True,
            check=True,
        )

        print(result.stdout)

        success("Release build completed successfully.")

    except subprocess.CalledProcessError as e:

        error("Release build failed.")
        print(e.stdout)
        print(e.stderr)

    except FileNotFoundError:

        error("Python or release script not found.")

    end_timer()