
"""
Kaivor Git Tools
"""

import subprocess

from modules.developer.ui import (
    title,
    start_timer,
    end_timer,
    error,
)


def git_status():

    start_timer()

    title("GIT STATUS")

    try:

        result = subprocess.run(
            ["git", "status"],
            capture_output=True,
            text=True,
            check=True,
        )

        print(result.stdout)

    except FileNotFoundError:

        error("Git is not installed.")

    except subprocess.CalledProcessError as e:

        error("Git command failed.")
        print(e.stdout)
        print(e.stderr)

    end_timer()