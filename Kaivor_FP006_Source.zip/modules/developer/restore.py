"""
Kaivor Restore Manager
"""

from pathlib import Path
import shutil

from modules.developer.ui import (
    title,
    start_timer,
    end_timer,
    success,
    warning,
    error,
)

BACKUP_ROOT = Path("backups")


def restore_backup():

    start_timer()

    title("RESTORE BACKUP")

    backups = sorted(
        [b for b in BACKUP_ROOT.iterdir() if b.is_dir()],
        reverse=True,
    )

    if not backups:
        error("No backups found.")
        end_timer()
        return

    for i, backup in enumerate(backups, start=1):
        print(f"{i}. {backup.name}")

    print()

    choice = input("Restore which backup (0 to cancel): ").strip()

    if choice == "0":
        warning("Restore cancelled.")
        end_timer()
        return

    try:
        backup = backups[int(choice) - 1]
    except Exception:
        error("Invalid selection.")
        end_timer()
        return

    confirm = input(
        "\nThis will overwrite project files. Continue? (y/N): "
    ).strip().lower()

    if confirm != "y":
        warning("Restore cancelled.")
        end_timer()
        return

    folders = [
        "core",
        "modules",
        "config",
        "scripts",
        "database",
    ]

    files = [
        "kaivor.py",
    ]

    for folder in folders:

        src = backup / folder

        if src.exists():

            shutil.copytree(
                src,
                folder,
                dirs_exist_ok=True,
            )

            success(folder)

    for file in files:

        src = backup / file

        if src.exists():

            shutil.copy2(
                src,
                file,
            )

            success(file)

    print()

    success("Restore completed successfully.")

    end_timer()