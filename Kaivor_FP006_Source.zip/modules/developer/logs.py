"""
Kaivor Log Tools
"""

from pathlib import Path


LOG_FILE = Path("logs/kaivor.log")


def view_log():

    print()
    print("=" * 50)
    print("          KAIVOR LOG")
    print("=" * 50)
    print()

    if LOG_FILE.exists():

        try:

            with open(LOG_FILE, "r", encoding="utf-8") as log:
                print(log.read())

        except Exception as error:
            print(f"Unable to read log file: {error}")

    else:

        print("No log file found.")

    print()


def clear_log():

    print()

    if not LOG_FILE.exists():

        print("No log file found.")
        return

    confirm = input("Clear the log file? (y/N): ").strip().lower()

    if confirm == "y":

        LOG_FILE.write_text("", encoding="utf-8")
        print("\nLog file cleared.")

    else:

        print("\nCancelled.")
