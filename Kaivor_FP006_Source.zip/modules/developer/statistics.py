
"""
Kaivor Project Statistics
"""

from pathlib import Path
from modules.developer.ui import title, start_timer, end_timer


def project_statistics():

    start_timer()

    title("PROJECT STATISTICS")

    project = Path(".")

    py_files = list(project.rglob("*.py"))
    md_files = list(project.rglob("*.md"))
    json_files = list(project.rglob("*.json"))
    log_files = list(project.rglob("*.log"))

    total_lines = 0

    for file in py_files:

        try:

            with open(file, "r", encoding="utf-8") as f:
                total_lines += len(f.readlines())

        except Exception:

            pass

    total_size = 0

    for file in project.rglob("*"):

        if file.is_file():

            try:

                total_size += file.stat().st_size

            except Exception:

                pass

    print(f"Python Files    : {len(py_files)}")
    print(f"Markdown Files  : {len(md_files)}")
    print(f"JSON Files      : {len(json_files)}")
    print(f"Log Files       : {len(log_files)}")
    print(f"Total Lines     : {total_lines}")
    print(f"Project Size    : {total_size / 1024:.1f} KB")

    end_timer()