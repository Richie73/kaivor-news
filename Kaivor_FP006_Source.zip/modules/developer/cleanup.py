"""
Kaivor Cache Cleaner
"""

from pathlib import Path
import shutil

from modules.developer.ui import (
    title,
    success,
    end_timer,
    start_timer,
)


def clean_pycache():

    start_timer()

    title("CLEAN __pycache__")

    removed = 0

    for folder in Path(".").rglob("__pycache__"):

        try:
            shutil.rmtree(folder)
            success(f"Removed {folder}")
            removed += 1

        except Exception:
            pass

    print()
    print(f"Removed {removed} cache folder(s).")

    end_timer()
